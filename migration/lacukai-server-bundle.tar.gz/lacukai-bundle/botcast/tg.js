const { TelegramClient, Api } = require('telegram');
const { StringSession } = require('telegram/sessions');
const { getPeerId } = require('telegram/Utils');
const QRCode = require('qrcode');
const db = require('./db');

// ─── Active Client Pool ───
const clients = new Map(); // accountId -> { client, session }
const pendingAuths = new Map(); // socketId -> { resolveCode }

// ─── Connect All Active Accounts on Startup ───
async function connectAllAccounts(io) {
  const accounts = db.prepare('SELECT * FROM accounts WHERE status = ?').all('active');
  console.log(`🔄 Reconnecting ${accounts.length} active accounts...`);

  for (const acc of accounts) {
    try {
      await connectAccount(acc, io);
      console.log(`  ✅ ${acc.phone || acc.username || acc.id} connected`);
    } catch (err) {
      console.log(`  ❌ ${acc.phone || acc.id} failed: ${err.message}`);
      db.prepare('UPDATE accounts SET status = ? WHERE id = ?').run('inactive', acc.id);
    }
  }

  // sanity check tiap 2 menit: kalau koneksi client mati, reconnect
  if (clients.size > 0) {
    setInterval(async () => {
      for (const [id, entry] of clients.entries()) {
        if (!entry.client.connected) {
          try {
            await entry.client.connect();
            console.log(`🔁 [acc ${id}] reconnected`);
          } catch (e) {
            console.log(`❌ [acc ${id}] reconnect gagal: ${e.message}`);
          }
        }
      }
    }, 120 * 1000).unref();
  }
}

// ─── Connect Single Account ───
async function connectAccount(acc, io) {
  if (clients.has(acc.id)) return clients.get(acc.id).client;

  const session = new StringSession(acc.session_string);
  const client = new TelegramClient(session, acc.api_id, acc.api_hash, {
    connectionRetries: 5,
    useWSS: false,
  });

  await client.connect();

  if (await client.checkAuthorization()) {
    const me = await client.getMe();
    db.prepare(`UPDATE accounts SET status = 'active', first_name = ?, last_name = ?, username = ? WHERE id = ?`)
      .run(me.firstName || '', me.lastName || '', me.username || '', acc.id);

    clients.set(acc.id, { client, session });
    if (io) io.emit('account-status', { id: acc.id, status: 'active' });
    return client;
  } else {
    throw new Error('Not authorized');
  }
}

// ─── Disconnect Account ───
async function disconnectAccount(accountId) {
  const entry = clients.get(accountId);
  if (entry) {
    await entry.client.disconnect();
    clients.delete(accountId);
  }
  db.prepare('UPDATE accounts SET status = ? WHERE id = ?').run('inactive', accountId);
}

// ─── QR Code Login ───
async function startQRLogin(apiId, apiHash, io, socketId) {
  const session = new StringSession('');
  const client = new TelegramClient(session, Number(apiId), apiHash, {
    connectionRetries: 5,
  });

  return new Promise(async (resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error('QR Login timeout (120s)'));
      client.disconnect().catch(() => {});
    }, 120000);

    try {
      await client.start({
        phoneNumber: async () => '',
        phoneCode: async () => '',
        qrCode: async (qr) => {
          try {
            const token = qr.token.toString('base64url');
            const qrUrl = `tg://login?token=${token}`;
            const qrImage = await QRCode.toDataURL(qrUrl, { width: 300 });
            io.to(socketId).emit('qr-code', { qrImage });
          } catch (e) {
            console.error('QR generation error:', e);
          }
        },
        password: async () => {
          io.to(socketId).emit('password-requested', {});
          return new Promise((resolvePw) => {
            pendingAuths.set(socketId, { resolveCode: resolvePw });
          });
        },
        onError: (err) => {
          console.error('Auth error:', err.message);
          io.to(socketId).emit('auth-error', { error: err.message });
        },
      });

      clearTimeout(timeout);
      const sessionString = client.session.save();
      const me = await client.getMe();

      const result = db.prepare(`
        INSERT OR REPLACE INTO accounts (phone, session_string, api_id, api_hash, status, first_name, last_name, username)
        VALUES (?, ?, ?, ?, 'active', ?, ?, ?)
      `).run(
        me.phone || '', sessionString, Number(apiId), apiHash,
        me.firstName || '', me.lastName || '', me.username || ''
      );

      const accId = result.lastInsertRowid || db.prepare('SELECT id FROM accounts WHERE phone = ?').get(me.phone)?.id;
      clients.set(accId, { client, session });
      io.to(socketId).emit('auth-success', { accountId: accId, name: me.firstName });
      resolve(accId);
    } catch (err) {
      clearTimeout(timeout);
      reject(err);
    }
  });
}

// ─── Phone + OTP Login ───
async function startPhoneLogin(apiId, apiHash, phoneNumber, io, socketId) {
  const session = new StringSession('');
  const client = new TelegramClient(session, Number(apiId), apiHash, {
    connectionRetries: 5,
  });

  return new Promise(async (resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error('Phone Login timeout (180s)'));
      client.disconnect().catch(() => {});
    }, 180000);

    try {
      await client.start({
        phoneNumber: async () => phoneNumber,
        phoneCode: async () => {
          io.to(socketId).emit('otp-requested', { phoneNumber });
          return new Promise((resolveCode) => {
            pendingAuths.set(socketId, { resolveCode });
          });
        },
        password: async () => {
          io.to(socketId).emit('password-requested', {});
          return new Promise((resolvePw) => {
            pendingAuths.set(socketId, { resolveCode: resolvePw });
          });
        },
        onError: (err) => {
          io.to(socketId).emit('auth-error', { error: err.message });
        },
      });

      clearTimeout(timeout);
      const sessionString = client.session.save();
      const me = await client.getMe();

      const result = db.prepare(`
        INSERT OR REPLACE INTO accounts (phone, session_string, api_id, api_hash, status, first_name, last_name, username)
        VALUES (?, ?, ?, ?, 'active', ?, ?, ?)
      `).run(
        phoneNumber, sessionString, Number(apiId), apiHash,
        me.firstName || '', me.lastName || '', me.username || ''
      );

      const accId = result.lastInsertRowid || db.prepare('SELECT id FROM accounts WHERE phone = ?').get(phoneNumber)?.id;
      clients.set(accId, { client, session });
      io.to(socketId).emit('auth-success', { accountId: accId, name: me.firstName });
      resolve(accId);
    } catch (err) {
      clearTimeout(timeout);
      reject(err);
    }
  });
}

function submitOTP(socketId, code) {
  const auth = pendingAuths.get(socketId);
  if (auth && auth.resolveCode) {
    auth.resolveCode(code);
    pendingAuths.delete(socketId);
  }
}

// ─── Get Client ───
function getClient(accountId) {
  const entry = clients.get(Number(accountId));
  return entry ? entry.client : null;
}

function getActiveClients() {
  return Array.from(clients.entries()).map(([id, { client }]) => ({ id, client }));
}

// ─── Send Message ───
async function sendMessage(accountId, target, message, mediaPath = null) {
  let client = getClient(accountId);
  if (!client) throw new Error('Account not connected');

  const opts = { message };
  if (mediaPath) opts.file = mediaPath;

  try {
    return await client.sendMessage(target, opts);
  } catch (err) {
    // koneksi stale/mati (TIMEOUT, disconnect) → reconnect 1x lalu coba lagi
    const isTransient = /TIMEOUT|not connected|disconnect/i.test(err.message) || !client.connected;
    if (!isTransient) throw err;
    console.log(`⚠️ [acc ${accountId}] koneksi stale (${err.message}), reconnect...`);
    try { await client.disconnect(); } catch (e) { /* ignore */ }
    await client.connect();
    if (!await client.checkAuthorization()) throw new Error('Session invalid, login ulang akun');
    return await client.sendMessage(target, opts);
  }
}

// ─── Resolve Title (untuk report) ───
const dialogCacheWarmed = new Set();
async function resolveTitle(accountId, target) {
  const client = getClient(accountId);
  if (!client) return '';
  try {
    const e = await client.getEntity(target);
    return e.title || e.username || String(target);
  } catch (err) {
    // entity belum di cache → load dialogs sekali supaya cache keisi
    if (!dialogCacheWarmed.has(accountId)) {
      dialogCacheWarmed.add(accountId);
      try { await client.getDialogs({ limit: 500 }); } catch (e2) { /* ignore */ }
      try {
        const e = await client.getEntity(target);
        return e.title || e.username || String(target);
      } catch (e2) { return ''; }
    }
    return '';
  }
}

// ─── Get Group Members ───
async function getGroupMembers(accountId, groupEntity, limit = 1000) {
  const client = getClient(accountId);
  if (!client) throw new Error('Account not connected');

  const members = [];
  const entity = await client.getEntity(groupEntity);

  const participants = await client.invoke(
    new Api.channels.GetParticipants({
      channel: entity,
      filter: new Api.ChannelParticipantsSearch({ q: '' }),
      offset: 0,
      limit: limit,
      hash: BigInt(0),
    })
  );

  if (participants && participants.users) {
    for (const user of participants.users) {
      members.push({
        id: user.id.toString(),
        username: user.username || '',
        first_name: user.firstName || '',
        last_name: user.lastName || '',
      });
    }
  }

  return { title: entity.title || '', username: entity.username || '', members };
}

// ─── Join Group ───
async function joinGroup(accountId, groupLink) {
  const client = getClient(accountId);
  if (!client) throw new Error('Account not connected');

  try {
    if (groupLink.includes('t.me/+') || groupLink.includes('t.me/joinchat/')) {
      const hash = groupLink.split('+')[1] || groupLink.split('/').pop();
      await client.invoke(new Api.messages.ImportChatInvite({ hash }));
    } else {
      const username = groupLink.replace('https://t.me/', '').replace('@', '');
      await client.invoke(new Api.channels.JoinChannel({ channel: username }));
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ─── Add Member to Group ───
async function addMemberToGroup(accountId, targetGroup, userId) {
  const client = getClient(accountId);
  if (!client) throw new Error('Account not connected');

  try {
    const entity = await client.getEntity(targetGroup);
    await client.invoke(
      new Api.channels.InviteToChannel({
        channel: entity,
        users: [Number(userId)],
      })
    );
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// ─── Spintax Parser ───
function parseSpintax(text) {
  return text.replace(/\{([^{}]+)\}/g, (_, group) => {
    const options = group.split('|');
    return options[Math.floor(Math.random() * options.length)];
  });
}

// ─── Sleep ───
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Scan Groups Joined (otomatis dari dialog yang pernah dijoin) ───
async function scanJoinedGroups(accountId) {
  const client = getClient(accountId);
  if (!client) throw new Error('Account not connected');

  const groups = [];
  const seen = new Set();
  for await (const dialog of client.iterDialogs()) {
    const e = dialog.entity;
    if (e.className !== 'Channel' && e.className !== 'Chat') continue;
    if (e.className === 'Channel' && !e.broadcast && !e.megagroup) continue;
    let type = 'group';
    if (e.className === 'Channel') type = e.broadcast ? 'channel' : 'supergroup';
    const id = getPeerId(e, true);
    if (seen.has(id)) continue;
    seen.add(id);
    groups.push({
      id,
      title: e.title || '',
      username: e.username || '',
      type,
      members: e.participantsCount || 0,
    });
  }
  groups.sort((a, b) => b.members - a.members);
  return groups;
}

module.exports = {
  connectAllAccounts,
  connectAccount,
  disconnectAccount,
  startQRLogin,
  startPhoneLogin,
  submitOTP,
  getClient,
  getActiveClients,
  sendMessage,
  resolveTitle,
  getGroupMembers,
  scanJoinedGroups,
  joinGroup,
  addMemberToGroup,
  parseSpintax,
  sleep,
  clients,
};
