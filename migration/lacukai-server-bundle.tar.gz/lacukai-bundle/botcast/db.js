const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, 'data.db');
const db = new Database(dbPath);

// Enable WAL mode for better concurrent performance
db.pragma('journal_mode = WAL');

function initDB() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      phone TEXT UNIQUE,
      session_string TEXT NOT NULL,
      api_id INTEGER NOT NULL,
      api_hash TEXT NOT NULL,
      proxy TEXT DEFAULT '',
      status TEXT DEFAULT 'inactive',
      first_name TEXT DEFAULT '',
      last_name TEXT DEFAULT '',
      username TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      mode TEXT DEFAULT 'group',
      message_text TEXT NOT NULL,
      media_path TEXT DEFAULT '',
      targets TEXT DEFAULT '[]',
      scan_id INTEGER DEFAULT NULL,
      use_spintax INTEGER DEFAULT 0,
      delay_min INTEGER DEFAULT 5,
      delay_max INTEGER DEFAULT 15,
      status TEXT DEFAULT 'pending',
      account_ids TEXT DEFAULT '[]',
      total_targets INTEGER DEFAULT 0,
      sent_count INTEGER DEFAULT 0,
      fail_count INTEGER DEFAULT 0,
      report TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      campaign_id INTEGER NOT NULL,
      interval_minutes INTEGER DEFAULT 0,
      interval_hours INTEGER DEFAULT 0,
      timezone TEXT DEFAULT 'Asia/Jakarta',
      is_active INTEGER DEFAULT 1,
      last_run DATETIME,
      next_run DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
    );

    CREATE TABLE IF NOT EXISTS scan_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      group_id TEXT NOT NULL,
      group_title TEXT DEFAULT '',
      group_username TEXT DEFAULT '',
      member_count INTEGER DEFAULT 0,
      members TEXT DEFAULT '[]',
      account_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS bulk_join_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT DEFAULT 'Bulk Join',
      links TEXT DEFAULT '[]',
      account_ids TEXT DEFAULT '[]',
      delay_seconds INTEGER DEFAULT 30,
      filter_min_members INTEGER DEFAULT 0,
      filter_enabled INTEGER DEFAULT 0,
      status TEXT DEFAULT 'pending',
      success_count INTEGER DEFAULT 0,
      fail_count INTEGER DEFAULT 0,
      report TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS add_member_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT DEFAULT 'Add Members',
      scan_id INTEGER NOT NULL,
      target_group TEXT NOT NULL,
      account_ids TEXT DEFAULT '[]',
      delay_seconds INTEGER DEFAULT 10,
      status TEXT DEFAULT 'pending',
      success_count INTEGER DEFAULT 0,
      fail_count INTEGER DEFAULT 0,
      report TEXT DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);
  console.log('✅ Database initialized');
}

initDB();
module.exports = db;
