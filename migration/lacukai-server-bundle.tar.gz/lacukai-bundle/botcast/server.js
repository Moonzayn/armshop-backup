const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');
const tg = require('./tg');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// ═══════════════════════════════════════════════
//  AUTH: token akses + anti-bruteforce
// ═══════════════════════════════════════════════
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const TOKEN_FILE = path.join(DATA_DIR, 'webui_token.txt');
if (!fs.existsSync(TOKEN_FILE)) fs.writeFileSync(TOKEN_FILE, crypto.randomBytes(24).toString('base64url'));
const APP_TOKEN = fs.readFileSync(TOKEN_FILE, 'utf8').trim();

const failMap = new Map();
function isBlocked(ip) { const f = failMap.get(ip); return !!f && Date.now() < f.until; }
function recordFail(ip) {
  const f = failMap.get(ip) || { n: 0, until: 0 };
  f.n++;
  if (f.n >= 5) { f.until = Date.now() + 15 * 60 * 1000; f.n = 5; console.log(`🔒 ${ip} diblokir 15 menit (5x token salah)`); }
  failMap.set(ip, f);
  return f;
}
const sweep = setInterval(() => { for (const [k, v] of failMap) if (Date.now() >= v.until) failMap.delete(k); }, 60 * 1000);
sweep.unref();

const sha = (s) => crypto.createHash('sha256').update(String(s)).digest();
function givenToken(req) {
  const c = (req.headers.cookie || '').match(/(?:^|;\s*)tms_tok=([^;]+)/);
  return decodeURIComponent(String(req.query.token || req.headers['x-token'] || (c && c[1]) || '').trim());
}
function tokenOk(req) {
  const g = givenToken(req);
  if (!g) return false;
  return crypto.timingSafeEqual(sha(g), sha(APP_TOKEN));
}
function setTok(res) {
  res.setHeader('Set-Cookie', `tms_tok=${encodeURIComponent(APP_TOKEN)}; Path=/; HttpOnly; Max-Age=2592000; SameSite=Lax`);
}
const TOKEN_PAGE = '<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Telegram Marketing Tools</title><meta name="viewport" content="width=device-width,initial-scale=1"></head>' +
  '<body style="font-family:system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;margin:0;background:#0f172a;color:#e2e8f0">' +
  '<div style="text-align:center"><h2>🔐 Telegram Marketing Tools</h2><p style="color:#94a3b8">Masukkan token akses:</p>' +
  '<input id="t" onkeydown="if(event.key==\'Enter\')go()" style="padding:10px;width:320px;border-radius:8px;border:1px solid #334155;background:#1e293b;color:#e2e8f0">' +
  '<button onclick="go()" style="padding:10px 18px;border-radius:8px;border:0;background:#10b981;color:#fff;cursor:pointer;margin-left:8px">Masuk</button>' +
  '<p id="m" style="color:#f87171;height:1.2em"></p></div>' +
  '<script>function go(){location="/?token="+encodeURIComponent(document.getElementById("t").value)}' +
  'if(new URLSearchParams(location.search).get("err"))document.getElementById("m").textContent="Token salah, coba lagi.";document.getElementById("t").focus()</script></body></html>';

app.use((req, res, next) => {
  const ip = String(req.headers['x-real-ip'] || req.socket.remoteAddress || '').replace('::ffff:', '');
  if (isBlocked(ip)) { res.setHeader('Retry-After', 900); return res.status(429).json({ error: 'Terlalu banyak percobaan salah. Diblokir 15 menit.' }); }
  if (tokenOk(req)) { if (req.query.token) setTok(res); return next(); }
  if (givenToken(req)) {
    const f = recordFail(ip);
    console.log(`🚫 Token salah dari ${ip} (${f.n}/5)`);
    return req.path.startsWith('/api/') || req.path.startsWith('/socket.io/')
      ? res.status(401).json({ error: `Token salah (${5 - f.n} percobaan sebelum diblokir)` })
      : res.redirect(303, '/?err=1');
  }
  return req.path.startsWith('/api/') || req.path.startsWith('/socket.io/')
    ? res.status(401).json({ error: 'unauthorized' })
    : res.status(401).send(TOKEN_PAGE);
});

// Socket.IO handshake juga harus bawa token
io.use((socket, next) => {
  const ip = String(socket.handshake.headers['x-real-ip'] || socket.handshake.address || '').replace('::ffff:', '');
  if (isBlocked(ip)) return next(new Error('blocked'));
  const c = (socket.handshake.headers.cookie || '').match(/(?:^|;\s*)tms_tok=([^;]+)/);
  const g = socket.handshake.query.token || (c && decodeURIComponent(c[1])) || '';
  if (!g) return next(new Error('unauthorized'));
  if (crypto.timingSafeEqual(sha(g), sha(APP_TOKEN))) return next();
  recordFail(ip);
  return next(new Error('unauthorized'));
});

// ─── Middleware ───
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Ensure uploads dir
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const upload = multer({ dest: uploadsDir });

// ─── Socket.IO ───
io.on('connection', (socket) => {
  console.log(`🔌 Client connected: ${socket.id}`);

  socket.on('submit-otp', (data) => {
    tg.submitOTP(socket.id, data.code);
  });

  socket.on('submit-password', (data) => {
    tg.submitOTP(socket.id, data.password);
  });

  socket.on('disconnect', () => {
    console.log(`🔌 Client disconnected: ${socket.id}`);
  });
});

// ═══════════════════════════════════════════════
//  ACCOUNT ROUTES
// ═══════════════════════════════════════════════

app.get('/api/accounts', (req, res) => {
  const accounts = db.prepare('SELECT id, phone, api_id, status, first_name, last_name, username, created_at FROM accounts ORDER BY id DESC').all();
  res.json(accounts);
});

app.post('/api/accounts/qr-login', async (req, res) => {
  const { apiId, apiHash } = req.body;
  const socketId = req.body.socketId;
  if (!apiId || !apiHash || !socketId) return res.status(400).json({ error: 'Missing fields' });

  res.json({ message: 'QR login started, check your dashboard' });

  try {
    await tg.startQRLogin(apiId, apiHash, io, socketId);
  } catch (err) {
    io.to(socketId).emit('auth-error', { error: err.message });
  }
});

app.post('/api/accounts/phone-login', async (req, res) => {
  const { apiId, apiHash, phoneNumber } = req.body;
  const socketId = req.body.socketId;
  if (!apiId || !apiHash || !phoneNumber || !socketId) return res.status(400).json({ error: 'Missing fields' });

  res.json({ message: 'Phone login started, waiting for OTP' });

  try {
    await tg.startPhoneLogin(apiId, apiHash, phoneNumber, io, socketId);
  } catch (err) {
    io.to(socketId).emit('auth-error', { error: err.message });
  }
});

app.post('/api/accounts/:id/toggle', async (req, res) => {
  const acc = db.prepare('SELECT * FROM accounts WHERE id = ?').get(req.params.id);
  if (!acc) return res.status(404).json({ error: 'Not found' });

  if (acc.status === 'active') {
    await tg.disconnectAccount(acc.id);
    res.json({ status: 'inactive' });
  } else {
    try {
      await tg.connectAccount(acc, io);
      res.json({ status: 'active' });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  }
});

app.delete('/api/accounts/:id', async (req, res) => {
  await tg.disconnectAccount(Number(req.params.id));
  db.prepare('DELETE FROM accounts WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// ═══════════════════════════════════════════════
//  BROADCAST ROUTES
// ═══════════════════════════════════════════════

app.get('/api/campaigns', (req, res) => {
  const campaigns = db.prepare('SELECT id, name, mode, status, total_targets, sent_count, fail_count, created_at FROM campaigns ORDER BY id DESC').all();
  res.json(campaigns);
});

app.post('/api/campaigns', upload.single('media'), (req, res) => {
  const { name, mode, message_text, targets, scan_id, use_spintax, delay_min, delay_max, account_ids } = req.body;
  const mediaPath = req.file ? req.file.path : '';

  if (!name || !message_text) return res.status(400).json({ error: 'Nama dan pesan wajib diisi' });
  const parsedAccounts = typeof account_ids === 'string' ? (JSON.parse(account_ids || '[]') || []) : (account_ids || []);
  if (!Array.isArray(parsedAccounts) || parsedAccounts.length === 0) {
    return res.status(400).json({ error: 'Pilih minimal 1 akun untuk campaign ini' });
  }
  if (mode === 'scan' && !scan_id) return res.status(400).json({ error: 'Pilih hasil scan untuk mode scan' });
  if ((mode || 'group') !== 'scan') {
    const parsedTargets = typeof targets === 'string' ? (JSON.parse(targets || '[]') || []) : (targets || []);
    if (!Array.isArray(parsedTargets) || parsedTargets.length === 0) {
      return res.status(400).json({ error: 'Isi minimal 1 target (@group / -100xxx / @username)' });
    }
  }

  const result = db.prepare(`
    INSERT INTO campaigns (name, mode, message_text, media_path, targets, scan_id, use_spintax, delay_min, delay_max, account_ids)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    name, mode || 'group', message_text, mediaPath,
    targets || '[]', scan_id || null,
    use_spintax ? 1 : 0,
    Number(delay_min) || 5, Number(delay_max) || 15,
    account_ids || '[]'
  );

  res.json({ id: result.lastInsertRowid, success: true });
});

app.post('/api/campaigns/:id/start', async (req, res) => {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(req.params.id);
  if (!campaign) return res.status(404).json({ error: 'Not found' });

  db.prepare("UPDATE campaigns SET status = 'running' WHERE id = ?").run(campaign.id);
  res.json({ message: 'Broadcast started' });

  // Run broadcast in background
  runBroadcast(campaign);
});

async function runBroadcast(campaign) {
  const accountIds = JSON.parse(campaign.account_ids || '[]');
  const activeAccounts = accountIds.filter(id => tg.getClient(id));

  if (activeAccounts.length === 0) {
    db.prepare("UPDATE campaigns SET status = 'failed', report = ? WHERE id = ?")
      .run(JSON.stringify([{ target: '-', status: 'failed', error: 'Tidak ada akun aktif terpilih. Edit campaign dan pilih akun.' }]), campaign.id);
    io.emit('broadcast-update', { id: campaign.id, status: 'failed', error: 'No active accounts' });
    return;
  }

  let targets = [];

  if (campaign.mode === 'scan' && campaign.scan_id) {
    const scan = db.prepare('SELECT * FROM scan_results WHERE id = ?').get(campaign.scan_id);
    if (scan) targets = JSON.parse(scan.members || '[]').map(m => m.id);
  } else {
    targets = JSON.parse(campaign.targets || '[]');
  }

  db.prepare('UPDATE campaigns SET total_targets = ? WHERE id = ?').run(targets.length, campaign.id);

  let sent = 0, failed = 0;
  const report = [];

  for (let i = 0; i < targets.length; i++) {
    const target = targets[i];
    const accId = activeAccounts[i % activeAccounts.length];
    const title = await tg.resolveTitle(activeAccounts[0], target);
    let msg = campaign.message_text;

    if (campaign.use_spintax) msg = tg.parseSpintax(msg);

    try {
      await tg.sendMessage(accId, campaign.mode === 'scan' ? Number(target) : target, msg, campaign.media_path || null);
      sent++;
      report.push({ target: String(target), title, status: 'sent', account: accId });
    } catch (err) {
      failed++;
      console.log(`❌ [campaign ${campaign.id}] target ${target} failed: ${err.message}`);
      report.push({ target: String(target), title, status: 'failed', error: err.message, account: accId });
    }

    db.prepare('UPDATE campaigns SET sent_count = ?, fail_count = ?, report = ? WHERE id = ?')
      .run(sent, failed, JSON.stringify(report), campaign.id);
    io.emit('broadcast-progress', { id: campaign.id, sent, failed, total: targets.length });

    // Delay
    const delay = Math.floor(Math.random() * (campaign.delay_max - campaign.delay_min + 1) + campaign.delay_min) * 1000;
    await tg.sleep(delay);
  }

  db.prepare("UPDATE campaigns SET status = 'completed', report = ? WHERE id = ?")
    .run(JSON.stringify(report), campaign.id);
  io.emit('broadcast-update', { id: campaign.id, status: 'completed', sent, failed });
}

app.get('/api/campaigns/:id/report', (req, res) => {
  const c = db.prepare('SELECT report, sent_count, fail_count, total_targets, status FROM campaigns WHERE id = ?').get(req.params.id);
  if (!c) return res.status(404).json({ error: 'Not found' });
  res.json(c);
});

app.delete('/api/campaigns/:id', (req, res) => {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(req.params.id);
  if (!campaign) return res.status(404).json({ error: 'Not found' });
  if (!['pending', 'completed', 'failed'].includes(campaign.status)) {
    return res.status(400).json({ error: 'Broadcast sedang berjalan, tunggu sampai selesai dulu' });
  }
  if (campaign.media_path && fs.existsSync(campaign.media_path)) {
    try { fs.unlinkSync(campaign.media_path); } catch (e) { /* ignore */ }
  }
  db.prepare('SELECT id FROM schedules WHERE campaign_id = ?').all(campaign.id)
    .forEach(s => stopSchedule(s.id));
  db.prepare('DELETE FROM schedules WHERE campaign_id = ?').run(campaign.id);
  db.prepare('DELETE FROM campaigns WHERE id = ?').run(campaign.id);
  res.json({ success: true });
});

// ═══════════════════════════════════════════════
//  SCANNER ROUTES
// ═══════════════════════════════════════════════

app.get('/api/scans', (req, res) => {
  const scans = db.prepare('SELECT id, group_title, group_username, member_count, created_at FROM scan_results ORDER BY id DESC').all();
  res.json(scans);
});

app.post('/api/scans', async (req, res) => {
  const { account_id, group, limit, mode } = req.body;
  if (!account_id) return res.status(400).json({ error: 'Missing fields' });

  try {
    // mode 'joined': scan otomatis semua grup/channel yang sudah dijoin akun
    if (mode === 'joined' || !group) {
      const groups = await tg.scanJoinedGroups(account_id);
      if (!groups.length) return res.json({ id: null, count: 0, title: '(tidak ada grup)' });
      const insert = db.prepare(`
        INSERT INTO scan_results (group_id, group_title, group_username, member_count, members, account_id)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run('joined', `Grup Sudah Dijoin (${groups.length})`, '', groups.reduce((a, g) => a + (g.members || 0), 0), JSON.stringify(groups), account_id);
      return res.json({ id: insert.lastInsertRowid, count: groups.length, title: `Grup Sudah Dijoin (${groups.length})` });
    }

    const result = await tg.getGroupMembers(account_id, group, Number(limit) || 1000);

    const insert = db.prepare(`
      INSERT INTO scan_results (group_id, group_title, group_username, member_count, members, account_id)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(group, result.title, result.username, result.members.length, JSON.stringify(result.members), account_id);

    res.json({ id: insert.lastInsertRowid, count: result.members.length, title: result.title });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/scans/:id', (req, res) => {
  const scan = db.prepare('SELECT * FROM scan_results WHERE id = ?').get(req.params.id);
  if (!scan) return res.status(404).json({ error: 'Not found' });
  scan.members = JSON.parse(scan.members || '[]');
  res.json(scan);
});

// ═══════════════════════════════════════════════
//  SCHEDULER ROUTES
// ═══════════════════════════════════════════════

const activeSchedules = new Map();

app.get('/api/schedules', (req, res) => {
  const schedules = db.prepare(`
    SELECT s.*, c.name as campaign_name 
    FROM schedules s 
    LEFT JOIN campaigns c ON s.campaign_id = c.id 
    ORDER BY s.id DESC
  `).all();
  res.json(schedules);
});

app.post('/api/schedules', (req, res) => {
  const { name, campaign_id, interval_minutes, interval_hours } = req.body;
  const result = db.prepare(`
    INSERT INTO schedules (name, campaign_id, interval_minutes, interval_hours)
    VALUES (?, ?, ?, ?)
  `).run(name, campaign_id, Number(interval_minutes) || 0, Number(interval_hours) || 0);

  const schedule = db.prepare('SELECT * FROM schedules WHERE id = ?').get(result.lastInsertRowid);
  startSchedule(schedule);
  res.json({ id: result.lastInsertRowid, success: true });
});

app.post('/api/schedules/:id/toggle', (req, res) => {
  const s = db.prepare('SELECT * FROM schedules WHERE id = ?').get(req.params.id);
  if (!s) return res.status(404).json({ error: 'Not found' });

  const newState = s.is_active ? 0 : 1;
  db.prepare('UPDATE schedules SET is_active = ? WHERE id = ?').run(newState, s.id);

  if (newState) {
    startSchedule(s);
  } else {
    stopSchedule(s.id);
  }

  res.json({ is_active: newState });
});

app.delete('/api/schedules/:id', (req, res) => {
  stopSchedule(Number(req.params.id));
  db.prepare('DELETE FROM schedules WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

function startSchedule(schedule) {
  stopSchedule(schedule.id);
  if (!schedule.is_active) return;

  const ms = ((schedule.interval_hours || 0) * 3600 + (schedule.interval_minutes || 0) * 60) * 1000;
  if (ms <= 0) return;

  const timer = setInterval(async () => {
    const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(schedule.campaign_id);
    if (campaign) {
      db.prepare("UPDATE campaigns SET status = 'running' WHERE id = ?").run(campaign.id);
      db.prepare('UPDATE schedules SET last_run = CURRENT_TIMESTAMP WHERE id = ?').run(schedule.id);
      io.emit('schedule-run', { scheduleId: schedule.id, campaignId: campaign.id });
      runBroadcast(campaign);
    }
  }, ms);

  activeSchedules.set(schedule.id, timer);
  console.log(`⏰ Schedule ${schedule.id} started (every ${ms / 1000}s)`);
}

function stopSchedule(id) {
  if (activeSchedules.has(id)) {
    clearInterval(activeSchedules.get(id));
    activeSchedules.delete(id);
  }
}

function loadAllSchedules() {
  const schedules = db.prepare('SELECT * FROM schedules WHERE is_active = 1').all();
  schedules.forEach(s => startSchedule(s));
  console.log(`⏰ Loaded ${schedules.length} active schedules`);
}

// ═══════════════════════════════════════════════
//  BULK JOIN ROUTES
// ═══════════════════════════════════════════════

app.get('/api/bulk-join', (req, res) => {
  const tasks = db.prepare('SELECT id, name, status, success_count, fail_count, created_at FROM bulk_join_tasks ORDER BY id DESC').all();
  res.json(tasks);
});

app.post('/api/bulk-join', upload.single('file'), async (req, res) => {
  let links = [];

  if (req.file) {
    const content = fs.readFileSync(req.file.path, 'utf-8');
    links = content.split('\n').map(l => l.trim()).filter(Boolean);
    fs.unlinkSync(req.file.path);
  } else if (req.body.links) {
    links = req.body.links.split('\n').map(l => l.trim()).filter(Boolean);
  }

  const { name, account_ids, delay_seconds, filter_min_members, filter_enabled } = req.body;

  const result = db.prepare(`
    INSERT INTO bulk_join_tasks (name, links, account_ids, delay_seconds, filter_min_members, filter_enabled)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    name || 'Bulk Join', JSON.stringify(links),
    account_ids || '[]', Number(delay_seconds) || 30,
    Number(filter_min_members) || 0, filter_enabled ? 1 : 0
  );

  res.json({ id: result.lastInsertRowid, linkCount: links.length });
});

app.post('/api/bulk-join/:id/start', async (req, res) => {
  const task = db.prepare('SELECT * FROM bulk_join_tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Not found' });

  db.prepare("UPDATE bulk_join_tasks SET status = 'running' WHERE id = ?").run(task.id);
  res.json({ message: 'Bulk join started' });

  runBulkJoin(task);
});

async function runBulkJoin(task) {
  const links = JSON.parse(task.links || '[]');
  const accountIds = JSON.parse(task.account_ids || '[]').filter(id => tg.getClient(id));

  if (accountIds.length === 0) {
    db.prepare("UPDATE bulk_join_tasks SET status = 'failed' WHERE id = ?").run(task.id);
    return;
  }

  let success = 0, failed = 0;
  const report = [];

  for (let i = 0; i < links.length; i++) {
    const link = links[i];
    const accId = accountIds[i % accountIds.length];

    // Filter check (optional)
    if (task.filter_enabled && task.filter_min_members > 0) {
      try {
        const client = tg.getClient(accId);
        const entity = await client.getEntity(link);
        if (entity.participantsCount && entity.participantsCount < task.filter_min_members) {
          report.push({ link, status: 'skipped', reason: 'Below min members' });
          continue;
        }
      } catch (e) { /* skip filter if can't check */ }
    }

    const result = await tg.joinGroup(accId, link);
    if (result.success) {
      success++;
      report.push({ link, status: 'joined', account: accId });
    } else {
      failed++;
      report.push({ link, status: 'failed', error: result.error, account: accId });
      // If flood wait, increase delay
      if (result.error.includes('FLOOD_WAIT') || result.error.includes('Too Many')) {
        await tg.sleep(60000);
      }
    }

    db.prepare('UPDATE bulk_join_tasks SET success_count = ?, fail_count = ? WHERE id = ?')
      .run(success, failed, task.id);
    io.emit('bulk-join-progress', { id: task.id, success, failed, total: links.length });

    await tg.sleep(task.delay_seconds * 1000);
  }

  db.prepare("UPDATE bulk_join_tasks SET status = 'completed', report = ? WHERE id = ?")
    .run(JSON.stringify(report), task.id);
  io.emit('bulk-join-update', { id: task.id, status: 'completed', success, failed });
}

// ═══════════════════════════════════════════════
//  ADD MEMBER ROUTES
// ═══════════════════════════════════════════════

app.get('/api/add-member', (req, res) => {
  const tasks = db.prepare('SELECT id, name, target_group, status, success_count, fail_count, created_at FROM add_member_tasks ORDER BY id DESC').all();
  res.json(tasks);
});

app.post('/api/add-member', async (req, res) => {
  const { name, scan_id, target_group, account_ids, delay_seconds } = req.body;

  const result = db.prepare(`
    INSERT INTO add_member_tasks (name, scan_id, target_group, account_ids, delay_seconds)
    VALUES (?, ?, ?, ?, ?)
  `).run(name || 'Add Members', scan_id, target_group, account_ids || '[]', Number(delay_seconds) || 10);

  res.json({ id: result.lastInsertRowid });
});

app.post('/api/add-member/:id/start', async (req, res) => {
  const task = db.prepare('SELECT * FROM add_member_tasks WHERE id = ?').get(req.params.id);
  if (!task) return res.status(404).json({ error: 'Not found' });

  db.prepare("UPDATE add_member_tasks SET status = 'running' WHERE id = ?").run(task.id);
  res.json({ message: 'Add member started' });

  runAddMembers(task);
});

async function runAddMembers(task) {
  const scan = db.prepare('SELECT * FROM scan_results WHERE id = ?').get(task.scan_id);
  if (!scan) return;

  const members = JSON.parse(scan.members || '[]');
  const accountIds = JSON.parse(task.account_ids || '[]').filter(id => tg.getClient(id));

  if (accountIds.length === 0) {
    db.prepare("UPDATE add_member_tasks SET status = 'failed' WHERE id = ?").run(task.id);
    return;
  }

  let success = 0, failed = 0;
  const report = [];

  for (let i = 0; i < members.length; i++) {
    const member = members[i];
    const accId = accountIds[i % accountIds.length];

    const result = await tg.addMemberToGroup(accId, task.target_group, member.id);
    if (result.success) {
      success++;
      report.push({ user: member.username || member.id, status: 'added' });
    } else {
      failed++;
      report.push({ user: member.username || member.id, status: 'failed', error: result.error });
    }

    db.prepare('UPDATE add_member_tasks SET success_count = ?, fail_count = ? WHERE id = ?')
      .run(success, failed, task.id);
    io.emit('add-member-progress', { id: task.id, success, failed, total: members.length });

    await tg.sleep(task.delay_seconds * 1000);
  }

  db.prepare("UPDATE add_member_tasks SET status = 'completed', report = ? WHERE id = ?")
    .run(JSON.stringify(report), task.id);
  io.emit('add-member-update', { id: task.id, status: 'completed' });
}

// ═══════════════════════════════════════════════
//  DASHBOARD ROUTES
// ═══════════════════════════════════════════════

app.get('/api/dashboard', (req, res) => {
  const totalAccounts = db.prepare('SELECT COUNT(*) as c FROM accounts').get().c;
  const activeAccounts = db.prepare("SELECT COUNT(*) as c FROM accounts WHERE status = 'active'").get().c;
  const totalBroadcasts = db.prepare('SELECT COUNT(*) as c FROM campaigns').get().c;
  const totalSent = db.prepare('SELECT COALESCE(SUM(sent_count),0) as c FROM campaigns').get().c;
  const totalFailed = db.prepare('SELECT COALESCE(SUM(fail_count),0) as c FROM campaigns').get().c;
  const totalScanned = db.prepare('SELECT COALESCE(SUM(member_count),0) as c FROM scan_results').get().c;
  const activeSchedulesCount = db.prepare('SELECT COUNT(*) as c FROM schedules WHERE is_active = 1').get().c;
  const recentCampaigns = db.prepare('SELECT id, name, status, sent_count, fail_count, created_at FROM campaigns ORDER BY id DESC LIMIT 5').all();

  res.json({
    totalAccounts, activeAccounts, totalBroadcasts,
    totalSent, totalFailed, totalScanned,
    activeSchedules: activeSchedulesCount, recentCampaigns,
  });
});

// ═══════════════════════════════════════════════
//  START SERVER
// ═══════════════════════════════════════════════

const PORT = process.env.PORT || 8811;

server.listen(PORT, '127.0.0.1', async () => {
  console.log(`\n🚀 Telegram Marketing Tools running at http://localhost:${PORT}\n`);
  // campaign yang tertinggal status 'running' pas restart server → balikin ke pending
  db.prepare("UPDATE campaigns SET status = 'pending' WHERE status = 'running'").run();
  await tg.connectAllAccounts(io);
  loadAllSchedules();
});
